/*
RFID OKUYUCU PROJES�
13 MART 2009 
WWW.HARMANKAYA.ORG


*/

#include <18F452.h>
#include <string.h>
#use delay(clock=4000000)
#define GLCD_WIDTH   128

#FUSES NOWDT                    //No Watch Dog Timer
#FUSES WDT128                   //Watch Dog Timer uses 1:128 Postscale
#FUSES HS                       //High speed Osc (> 4mhz)
#FUSES NOPROTECT                //Code not protected from reading
#FUSES NOOSCSEN                 //Oscillator switching is disabled, main oscillator is source
#FUSES BROWNOUT                 //Reset when brownout detected
#FUSES BORV27                   //Brownout reset at 2.7V
#FUSES NOPUT                    //No Power Up Timer
#FUSES STVREN                   //Stack full/underflow will cause reset
#FUSES NODEBUG                  //No Debug mode for ICD
#FUSES NOLVP                    //No low voltage prgming, B3(PIC16) or B5(PIC18) used for I/O
#FUSES NOWRT                    //Program memory not write protected
#FUSES NOWRTD                   //Data EEPROM not write protected
#FUSES NOWRTB                   //Boot block not write protected
#FUSES NOWRTC                   //configuration not registers write protected
#FUSES NOCPD                    //No EE protection
#FUSES NOCPB                    //No Boot Block code protection
#FUSES NOEBTR                   //Memory not protected from table reads
#FUSES NOEBTRB                  //Boot block not protected from table reads 
#FUSES CCP2B3                   //�nemli!!!!


//------------{LCD i�in pin de�i�iklikleri yap�l�yor}-------------------

#define GLCD_CS1                 PIN_E0
#define GLCD_CS2                 PIN_E1
#define GLCD_RST                 PIN_C3
#define GLCD_DI                  PIN_C1

//-----------{}------------------------------

#include "HDM64GS12.c"
#include "graphics.c"
#include <em4095.c>
#include <em4102.c>


#use fast_io(A)

   
   

   char text[] = "RFID SISTEMI";
   char text2[] = "Microchip PIC";
   
   int8  wrong_attemps;
   int32 tagNum;
   int8  customerCode;
   
   int8 msg[32];
   int8 kodum[32];
   int8 code[5];
   



//------------{}--------------------------

void main()
{
   SET_TRIS_A( 0x00 );
   setup_adc_ports (RA0_ANALOG);
   setup_adc (ADC_OFF);
   set_adc_channel (0);
   setup_psp (PSP_DISABLED);
   SETUP_SPI (SPI_MASTER|SPI_CLK_DIV_16|SPI_H_TO_L|SPI_XMIT_L_TO_H);  
   setup_wdt (WDT_OFF);
   setup_timer_0 (RTCC_INTERNAL);
   setup_timer_1 (T1_INTERNAL|T1_DIV_BY_1);
   setup_timer_2 (T2_DISABLED, 0, 1);
   setup_timer_2 (T2_DIV_BY_4, 255, 4);
   setup_timer_3 (T3_DISABLED|T3_DIV_BY_1);
   disable_interrupts (GLOBAL);
   


   rf_init();    //rfid y�klemesini yap
   
   rf_powerUp(); //mod�l� �al��t�r

   wrong_attemps = 0;
     
   glcd_init (ON);
   
   while (1)
   {

     
      
      if(read_4102(code))  //kart antene yapka�t�r�l�nca
      {
         tagNum = make32(code[1],code[2],code[3],code[4]);
         customerCode = code[0];
         sprintf(kodum,"\r\nOkunan ID: %u-%lu",customerCode,tagNum);  
         glcd_fillScreen (0);  //ekran� sil
         glcd_text57 (10, 24, kodum, 1, ON) ; //yeni kodu ekrana yaz
                  

      }
      
      
    
}

}


